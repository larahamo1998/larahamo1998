package com.techelevator.tenmo.dao;

import com.techelevator.tenmo.model.BalanceDTO;
import com.techelevator.tenmo.model.TransferDTO;
import com.techelevator.tenmo.model.User;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public interface TransferDao {



  String createTransfer(TransferDTO transferDTO);

   //String createTransfer(int senderUserId, int recipientUserId, BigDecimal transferAmount, String recipientUsername);


   List<TransferDTO> getAllTransfers(int user_id);

   TransferDTO getTransferById(int transferId);


   List<User> getSendableUsers(int id);


}
