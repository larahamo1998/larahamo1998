package com.techelevator.tenmo.dao;

import com.techelevator.tenmo.model.BalanceDTO;

import java.math.BigDecimal;

public interface AccountDao {

    BalanceDTO getAccountById(int id);

    public boolean updateBalance(String username, BigDecimal transferAmount);

    public BalanceDTO getBalance(String username);

    public int findAccountIdByUserId(int userid);


    boolean create (int user_id);


}
