package com.techelevator.tenmo.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;

public class TransferDTO {

    @JsonIgnore
    private int accountFrom;
    @JsonIgnore
    private int accountTo;

    private String from;
    private String to;

    private int transferId;
    @JsonIgnore
    private int sendingAccountId;
    @JsonIgnore

    private int receivingAccountId;
    private BigDecimal transferAmount;

    private String transferStatus;

    public void setFrom(String from) {
        this.from = from;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public int getAccountFrom() {
        return accountFrom;
    }

    public int getAccountTo() {
        return accountTo;
    }

    public void setAccountFrom(int accountFrom) {
        this.accountFrom = accountFrom;
    }

    public void setAccountTo(int accountTo) {
        this.accountTo = accountTo;
    }


    public void setTransferId(int transferId) {
        this.transferId = transferId;
    }

    public void setSendingAccountId(int sendingAccountId) {
        this.sendingAccountId = sendingAccountId;
    }

    public void setReceivingAccountId(int receivingAccountId) {
        this.receivingAccountId = receivingAccountId;
    }

    public void setTransferAmount(BigDecimal transferAmount) {
        this.transferAmount = transferAmount;
    }

    public void setTransferStatus(String transferStatus) {
        this.transferStatus = transferStatus;
    }

    public int getTransferId() {
        return transferId;
    }

    public int getSendingAccountId() {
        return sendingAccountId;
    }

    public int getReceivingAccountId() {
        return receivingAccountId;
    }

    public BigDecimal getTransferAmount() {
        return transferAmount;
    }

    public String getTransferStatus() {
        return transferStatus;
    }

    @Override
    public String toString() {
        return "TransferDTO{" +
                "accountFrom=" + accountFrom +
                ", accountTo=" + accountTo +
                ", from='" + from + '\'' +
                ", to='" + to + '\'' +
                ", transferId=" + transferId +
                ", sendingAccountId=" + sendingAccountId +
                ", receivingAccountId=" + receivingAccountId +
                ", transferAmount=" + transferAmount +
                ", transferStatus='" + transferStatus + '\'' +
                '}';
    }
}
