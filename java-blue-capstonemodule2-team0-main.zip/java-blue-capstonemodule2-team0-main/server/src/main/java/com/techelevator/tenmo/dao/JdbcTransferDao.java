package com.techelevator.tenmo.dao;

import com.techelevator.tenmo.model.BalanceDTO;
import com.techelevator.tenmo.model.TransferDTO;
import com.techelevator.tenmo.model.User;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
@Component

public class JdbcTransferDao implements TransferDao{

    private JdbcTemplate jdbcTemplate;

    public JdbcTransferDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;

    }

    public BigDecimal getBalanceByAccountId(int accountId){
        String sql = "SELECT balance from account WHERE account_id = ?";
        try{
            return jdbcTemplate.queryForObject(sql, BigDecimal.class, accountId);
        } catch(DataAccessException e){
            throw new IllegalArgumentException("Account not found.");
        }
    }

    @Override
    public String createTransfer(TransferDTO transferDTO) {


        int sendingAccountId = transferDTO.getSendingAccountId();
        int receivingAccountId = transferDTO.getReceivingAccountId();


        //current balances
        BigDecimal currentRecipientBalance = getBalanceByAccountId(transferDTO.getReceivingAccountId());
        BigDecimal currentSenderBalance = getBalanceByAccountId(transferDTO.getSendingAccountId());

        if(currentSenderBalance.compareTo(transferDTO.getTransferAmount()) < 0){
            throw new InsufficientBalanceException("Insufficient Balance.");
        }

        if(transferDTO.getTransferAmount().compareTo(BigDecimal.ZERO) <= 0){
            throw new IllegalArgumentException("Cannot send $0");
        }

        if(sendingAccountId == receivingAccountId){
            throw new IllegalArgumentException("Cannot send money to yourself.");
        }

        //transferring
        BigDecimal newRecipientBalance = currentRecipientBalance.add(transferDTO.getTransferAmount());
        BigDecimal newSenderBalance = currentSenderBalance.subtract(transferDTO.getTransferAmount());

        //updating
        updateBalanceByAccountId(transferDTO.getReceivingAccountId(), newRecipientBalance);
        updateBalanceByAccountId(transferDTO.getSendingAccountId(), newSenderBalance);

        String sql ="INSERT INTO transfer (sending_account_id, receiving_account_id, " +
        "transfer_amount ,transfer_status) VALUES (?, ?, ?, ?) RETURNING transfer_id";

        try {
            int newTransferId= jdbcTemplate.queryForObject(sql, int.class, transferDTO.getSendingAccountId(), transferDTO.getReceivingAccountId(), transferDTO.getTransferAmount(), "Approved");

            transferDTO.setTransferId(newTransferId);

            return "Approved.";
        }catch (DataAccessException e) {
            throw new IllegalArgumentException("Error creating transfer.");
        }


    }

    private void updateBalanceByAccountId(int accountId, BigDecimal newBalance) {
        String sql = "UPDATE account SET balance = ? WHERE account_id = ?";
        jdbcTemplate.update(sql, newBalance, accountId);
    }


    @Override
    public List<TransferDTO> getAllTransfers(int user_id) {
        List<TransferDTO> allTransfers = new ArrayList<>();
        String sql = "SELECT transfer_id, sending_account_id, receiving_account_id, transfer_amount, transfer_status FROM transfer " +
                "JOIN account ON (transfer.sending_account_id = account.account_id OR transfer.receiving_account_id = account.account_id) " +
                "JOIN tenmo_user ON account.user_id = tenmo_user.user_id " +
                "WHERE tenmo_user.user_id = ? AND (transfer_status = 'Approved' OR transfer_status = 'Rejected')";
        SqlRowSet results = jdbcTemplate.queryForRowSet(sql, user_id);
        while (results.next()) {
            allTransfers.add(mapRow(results));
        }

        return allTransfers;
    }

    @Override
    public TransferDTO getTransferById(int transferId) {

        String sql = "SELECT * FROM transfer WHERE transfer_id = ?";
        try {
            return jdbcTemplate.queryForObject(sql, new RowMapper<TransferDTO>() {
                @Override
                public TransferDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
                    TransferDTO transferDTO = new TransferDTO();
                    transferDTO.setTransferId(rs.getInt("transfer_id"));
                    transferDTO.setSendingAccountId(rs.getInt("sending_account_id"));
                    transferDTO.setReceivingAccountId(rs.getInt("receiving_account_id"));
                    transferDTO.setTransferAmount(rs.getBigDecimal("transfer_amount"));
                    transferDTO.setTransferStatus(rs.getString("transfer_status"));

                    String fromUsername = getUsernameByAccountId(transferDTO.getSendingAccountId());
                    String toUsername = getUsernameByAccountId(transferDTO.getReceivingAccountId());


                    if (fromUsername != null && toUsername != null) {
                        transferDTO.setFrom(fromUsername);
                        transferDTO.setTo(toUsername);

                    }  return transferDTO;
                }
            }, transferId);
        } catch (EmptyResultDataAccessException e) {
            return null;
        }


    }




        private TransferDTO mapRow (SqlRowSet rs){
            TransferDTO transferDTO = new TransferDTO();

            transferDTO.setTransferId(rs.getInt("transfer_id"));
            transferDTO.setSendingAccountId(rs.getInt("sending_account_id"));
            transferDTO.setReceivingAccountId(rs.getInt("receiving_account_id"));
            transferDTO.setTransferAmount(rs.getBigDecimal("transfer_amount"));
            transferDTO.setTransferStatus(rs.getString("transfer_status"));


            //to and from printing correctly in step 6
            String fromUsername = getUsernameByAccountId(transferDTO.getSendingAccountId());
            String toUsername = getUsernameByAccountId(transferDTO.getReceivingAccountId());

            transferDTO.setFrom(fromUsername);
            transferDTO.setTo(toUsername);

            return transferDTO;


        }

    private String getUsernameByAccountId(int accountId) {
        String sql = "SELECT tenmo_user.username FROM tenmo_user " +
                "JOIN account ON tenmo_user.user_id = account.user_id " +
                "WHERE account.account_id = ?";
        return jdbcTemplate.queryForObject(sql, String.class, accountId);
    }


    @Override
    public List<User> getSendableUsers(int id) {
        List<User> sendableUsers = new ArrayList<>();

        String sql = "SELECT tenmo_user.user_id, tenmo_user.username " +
        "FROM tenmo_user " +
                "JOIN account ON tenmo_user.user_id = account.user_id " +
                "WHERE tenmo_user.user_id != ? AND balance > 0";

        SqlRowSet results = jdbcTemplate.queryForRowSet(sql, id);
        while(results.next()) {

            sendableUsers.add(mapRowSendableUsers(results));
        }
        return sendableUsers;

}


    private User mapRowSendableUsers(SqlRowSet rs){
        User user = new User();
        user.setId(rs.getInt("user_id"));
        user.setUsername(rs.getString("username"));
        return user;
    }

    public class InsufficientBalanceException extends RuntimeException {
        public InsufficientBalanceException(String message) {
            super(message);
        }
    }
}



