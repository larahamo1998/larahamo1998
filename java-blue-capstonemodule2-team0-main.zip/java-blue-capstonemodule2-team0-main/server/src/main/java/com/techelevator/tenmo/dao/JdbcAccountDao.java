package com.techelevator.tenmo.dao;

import com.techelevator.tenmo.model.BalanceDTO;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;

import java.math.BigDecimal;
@Component
public class JdbcAccountDao implements  AccountDao{

    private JdbcTemplate jdbcTemplate;

    public JdbcAccountDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }


    public BalanceDTO getBalance(String username){

        String sql = "SELECT  account_id, balance, account.user_id, tenmo_user.username \n" +
                "FROM account\n" +
                "JOIN tenmo_user ON account.user_id = tenmo_user.user_id\n" +
                "WHERE tenmo_user.username = ?;";

        BalanceDTO balanceDTO = null;

        try {
            SqlRowSet results = jdbcTemplate.queryForRowSet(sql, username);
            if(results.next()) {
//                String user = results.getString("tenmo_user.username");
                int accountId = results.getInt("account_id");
                BigDecimal balance = results.getBigDecimal("balance");
                String user =results.getString("username");
                int userId = results.getInt("user_id");

                balanceDTO = new BalanceDTO();
                balanceDTO.setUserId(userId);
                balanceDTO.setAccountId(accountId);
                balanceDTO.setUsername(user);
                balanceDTO.setBalance(balance);

            }
        } catch (DataAccessException e) {
            e.printStackTrace();
        }

        return balanceDTO;
    }

    @Override
    public int findAccountIdByUserId(int userid) {

        String sql = "SELECT account.account_id from account " +
                "JOIN tenmo_user ON account.user_id = tenmo_user.user_id " +
                "WHERE tenmo_user.user_id = ?";

        SqlRowSet result = jdbcTemplate.queryForRowSet(sql, userid);

        int accountId = -1;

        if(result.next()) {
            accountId = result.getInt("account_id");
        }

        return accountId;
    }


    @Override
    public BalanceDTO getAccountById(int id) {
        String sql = "SELECT account.account_id, account.user_id, account.balance FROM account " +
                "JOIN tenmo_user ON account.user_id = tenmo_user.user_id " +
                "WHERE account.user_id = ? ";
        SqlRowSet results = jdbcTemplate.queryForRowSet(sql, id);

        BalanceDTO balanceDTO = null;

        if (results.next()) {
             balanceDTO = mapRowToAccount(results);
        }
        return balanceDTO;
    }

    public boolean create(int user_id){

        String sql = "INSERT INTO account(user_id, balance) VALUES (?, ?) RETURNING account_id;";

        try{

            jdbcTemplate.queryForObject(sql, Integer.class, user_id);
            return true;
        }catch (ResourceAccessException e){

            return  false;
        }
    }




    // method below not needed as of yet
    @Override
    public boolean updateBalance(String accountId, BigDecimal amount) {
        String sql = "UPDATE account SET balance = ? WHERE account_id = ?";

        try{
            jdbcTemplate.update(sql, amount, accountId);
            return true;
        }catch(DataAccessException e){
            return false;
        }
    }



    private BalanceDTO mapRowToAccount(SqlRowSet rs) {
        BalanceDTO balanceDTO = new BalanceDTO();
       balanceDTO.setAccountId(rs.getInt("account_id"));
       balanceDTO.setUserId(rs.getInt("user_id"));
       balanceDTO.setBalance(rs.getBigDecimal("balance"));

       return balanceDTO ;
    }
}
