package com.techelevator.tenmo.controller;


import com.techelevator.tenmo.dao.AccountDao;
import com.techelevator.tenmo.dao.TransferDao;
import com.techelevator.tenmo.dao.UserDao;
import com.techelevator.tenmo.model.BalanceDTO;
import com.techelevator.tenmo.model.TransferDTO;
import com.techelevator.tenmo.model.User;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.security.Principal;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController

@PreAuthorize("isAuthenticated()")
public class AccountController {


    private AccountDao accountDao;
    private UserDao userDao;

    private TransferDao transferDao;



    public AccountController(UserDao userDao, AccountDao accountDao, TransferDao transferDao) {

        this.userDao = userDao;
        this.accountDao = accountDao;
        this.transferDao = transferDao;
    }


    @RequestMapping(path = "/balance", method = RequestMethod.GET)
    public BalanceDTO createAccount(Principal principal) {

        //1. I know who the token belongs to
        String username = principal.getName();


        //2. Given the username, I cna use the user dao to get me back the user object
        User user = userDao.findByUsername(username);

        //3. so the user id is...
        int userId = user.getId();

        //4. I need a method inside of one of my DAO classes, this method makes
        //a sql call to the account table, and retrieves the account id for that user id
        return accountDao.getBalance(username);
    }
   // As an authenticated user of the system, I need to be able to send a transfer of a specific amount of TE Bucks to a registered user.


    @RequestMapping(path = "/transfer", method = RequestMethod.POST)
            public ResponseEntity<Map<String, Object>> transferMoney(@RequestBody TransferDTO transferRequest, Principal principal) {
                System.out.println(transferRequest);

                try {
                    // Get the username from the Principal
                    String senderUsername = principal.getName();
                   //added line below
                    String recipientUsername = transferRequest.getTo();

                    // Retrieve the user object using the user dao
                    User sender = userDao.findByUsername(principal.getName());

                    // Get the recipient user object
                    User recipient = userDao.findByUsername(transferRequest.getTo());

                    // Validate recipient
                    if (recipient == null) {
                        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null); // Handle invalid recipient
                    }

                    // Get the sender and recipient account IDs

                    //added
                    int senderUserId = userDao.findIdByUsername(senderUsername);
                    int recipientUserId = userDao.findIdByUsername(recipientUsername);



                    int senderAccountId = accountDao.findAccountIdByUserId(sender.getId());
                    int recipientAccountId = accountDao.findAccountIdByUserId(recipient.getId());

                    // Create a TransferDTO
                    TransferDTO transferDTO = new TransferDTO();
                    transferDTO.setSendingAccountId(senderAccountId);
                    transferDTO.setReceivingAccountId(recipientAccountId);
                    transferDTO.setTransferAmount(transferRequest.getTransferAmount());
                    transferDTO.setTo(transferRequest.getTo());
                    transferDTO.setFrom(transferRequest.getFrom());

                    // Call the createTransfer method from your TransferDao
                    transferDao.createTransfer(transferDTO);

                    // Build the response
                    Map<String, Object> response = new HashMap<>();
                    response.put("transferId", transferDTO.getTransferId());
                    response.put("transferAmount", transferDTO.getTransferAmount());
                    response.put("from", sender.getUsername());
                    response.put("to", recipient.getUsername());

                    return ResponseEntity.ok(response);
                } catch (Exception e) {
                    // Handle exceptions or validation errors
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
                }
            }



    @RequestMapping(path = "/transfer", method = RequestMethod.GET)
    public List<TransferDTO> getAllTransfers(Principal principal) {
        int userId = getUserId(principal);

        String senderUsername = principal.getName();

        // Retrieve the user object using the user dao
        User sender = userDao.findByUsername(senderUsername);

        if (sender == null) {
            return Collections.emptyList();
        }

        return transferDao.getAllTransfers(userId);
    }

    @RequestMapping(path = "/transfer/{transferId}", method = RequestMethod.GET)
    public TransferDTO getTransferById(@PathVariable int transferId) {
        return transferDao.getTransferById(transferId);
    }



   //I need an endpoint that shows the users I can send money to.
    @RequestMapping(path= "/transfer/sendable-users", method =RequestMethod.GET)
    public List<User> getSendableUsers(Principal principal) {
        int userId = getUserId(principal);
        List<User> sendableUsers = transferDao.getSendableUsers(userId);

        return sendableUsers;
    }


    private int getUserId(Principal principal) {
        String username = principal.getName();
        return userDao.findIdByUsername(username);
    }


}
